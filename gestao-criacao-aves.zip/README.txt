# Gestão da Criação de Aves

Aplicação web gratuita e local para gerir aves, vendas e despesas.

## Colocar online gratuitamente
A forma mais simples é usar GitHub Pages:
1. Cria uma conta gratuita em GitHub.
2. Cria um novo repositório, por exemplo `gestao-criacao-aves`.
3. Carrega o ficheiro `index.html`.
4. Em Settings > Pages, escolhe Deploy from a branch, seleciona `main` e `/root`.
5. O GitHub fornece o endereço público da aplicação.

## Importante
Esta primeira versão guarda os dados no navegador (localStorage). Isso é ótimo para começar rapidamente, mas os dados não sincronizam automaticamente entre dispositivos/navegadores.
A palavra-passe inicial é 1234 e pode ser alterada em Definições. Como a aplicação é estática, esta palavra-passe não deve ser considerada segurança forte para dados sensíveis.
